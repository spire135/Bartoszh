package pl.wsiz.kalkulatorbmi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.ViewHolder> {
  private List<Result> results;

  public ResultAdapter(List<Result> results) {
    this.results = results;
  }

  @NonNull
  @Override
  public ResultAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row, parent, false);
    return new ViewHolder(view);
  }

  @Override
  public void onBindViewHolder(@NonNull ResultAdapter.ViewHolder holder, int position) {
    holder.name.setText(results.get(position).name);
    holder.result.setText(String.valueOf(results.get(position).result));
  }

  @Override
  public int getItemCount() {
    return results.size();
  }

  public class ViewHolder extends RecyclerView.ViewHolder {
    TextView name, result;

    ViewHolder(View itemView) {
      super(itemView);
      name = itemView.findViewById(R.id.itemImie);
      result = itemView.findViewById(R.id.itemWynik);
    }
  }
}
