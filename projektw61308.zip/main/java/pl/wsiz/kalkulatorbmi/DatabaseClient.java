package pl.wsiz.kalkulatorbmi;

import android.content.Context;

import androidx.room.Room;

public class DatabaseClient {
  private Context context;
  private static DatabaseClient databaseClient;

  private BmrDatabase database;

  public DatabaseClient(Context context) {
    this.context = context;
    this.database = Room.databaseBuilder(context,BmrDatabase.class,"database").build();
  }

  public static synchronized DatabaseClient getInstance(Context ctx){
    if (databaseClient==null)
      databaseClient=new DatabaseClient(ctx);
    return databaseClient;
  }

  public BmrDatabase getBmrDatabase(){
    return database;
  }
}
