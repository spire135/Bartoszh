package pl.wsiz.kalkulatorbmi;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Result {
  @PrimaryKey(autoGenerate = true)
  int id;
  @ColumnInfo(name = "name")
  String name;
  @ColumnInfo(name = "result")
  float result;

  public Result() {
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public float getResult() {
    return result;
  }

  public void setResult(float result) {
    this.result = result;
  }
}
