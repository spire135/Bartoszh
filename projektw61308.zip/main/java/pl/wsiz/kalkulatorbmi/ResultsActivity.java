package pl.wsiz.kalkulatorbmi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.List;

public class ResultsActivity extends AppCompatActivity {
  RecyclerView recyclerView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_results);

    recyclerView = findViewById(R.id.resultList);

    recyclerView.setLayoutManager(new LinearLayoutManager(this));
    recyclerView.setAdapter(new ResultAdapter(getData()));
  }

  private List<Result> getData() {
    return BmrDatabase.getAppDatabase(this).resultDAO().getAllResults();
  }
}
